function loadOffices(data){

let container = document.getElementById("offices");

data.forEach(function(office){

let div = document.createElement("div");
div.className="office";

div.innerHTML = `
<div class="city">${office.city}</div>

<div class="officeContent">

<img src="${office.picture}">

<div class="data">
<p><b>Telèfon:</b> ${office.phone}</p>
<p><b>Direcció:</b> ${office.addressLine1}, ${office.addressLine2 ?? ""}</p>
<p><b>Estat:</b> ${office.state ?? "NULL"}</p>
<p><b>País:</b> ${office.country} - ${office.territory}</p>
</div>

</div>
`;

container.appendChild(div);

});

}