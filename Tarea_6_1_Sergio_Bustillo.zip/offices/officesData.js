loadOffices([
{
"officeCode":"1",
"picture":"https://upload.wikimedia.org/wikipedia/commons/6/61/San_Francisco_from_the_Marin_Headlands_in_August_2022.jpg",
"city":"San Francisco",
"phone":"+1 650 219 4782",
"addressLine1":"100 Market Street",
"addressLine2":"Suite 300",
"state":"CA",
"country":"USA",
"postalCode":"94080",
"territory":"NA"
},
{
"officeCode":"2",
"picture":"https://upload.wikimedia.org/wikipedia/commons/d/d7/Boston_-_panoramio_%2823%29.jpg",
"city":"Boston",
"phone":"+1 215 837 0825",
"addressLine1":"1550 Court Place",
"addressLine2":"Suite 102",
"state":"MA",
"country":"USA",
"postalCode":"02107",
"territory":"NA"
}
]);